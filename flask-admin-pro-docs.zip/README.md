# Flask Admin Pro

[![PyPI version](https://badge.fury.io/py/flask-admin-pro.svg)](https://badge.fury.io/py/flask-admin-pro)
[![Python Support](https://img.shields.io/pypi/pyversions/flask-admin-pro.svg)](https://pypi.org/project/flask-admin-pro/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

一个可嵌入现有 Flask 项目的后台管理系统，支持自动适配 ORM、CRUD 生成、接口监控和用户管理。

## ✨ 特性

- 🔌 **即插即用** - 通过特殊 URI (`/__admin__/`) 访问，不影响现有路由
- 🔄 **ORM 自适应** - 自动检测 SQLAlchemy/Peewee 等 ORM 框架
- 📊 **自动 CRUD** - 根据模型字段动态生成表单和列表
- 📈 **接口监控** - 自动记录 API 请求日志和性能指标
- 👥 **用户管理** - 内置用户/角色/权限系统
- 🎨 **响应式设计** - Bootstrap 5，支持移动端

## 📦 安装

### 从 PyPI 安装（推荐）

```bash
pip install flask-admin-pro
```

### 从源码安装

```bash
git clone https://github.com/yourusername/flask-admin-pro.git
cd flask-admin-pro
pip install -e .
```

### 安装开发版本

```bash
pip install flask-admin-pro[dev]
```

## 🚀 快速开始

### 方式 1: 作为 Python 包使用

```python
# app.py
from flask import Flask
from flask_admin_pro import AdminPro
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'

db = SQLAlchemy(app)
admin = AdminPro(app, db=db)

# 定义你的模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True)
    email = db.Column(db.String(120), unique=True)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128))
    price = db.Column(db.Float)

# 注册模型到管理后台
admin.register_models(User, Product)

# 初始化数据库
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
```

运行：
```bash
python app.py
```

访问：**http://localhost:5000/__admin__/**

### 方式 2: 使用 CLI 命令

```bash
# 初始化数据库
flask admin-init-db

# 创建管理员账户
flask admin-init-user --username admin --password admin123

# 注册模型（在代码中配置）
flask admin-register-models
```

### 方式 3: 完整示例项目

```bash
# 使用模板项目
cd flask-admin-pro
pip install -r requirements.txt

# 初始化
flask init-db
flask init-admin
flask register-models

# 启动
python run.py
```

访问：**http://localhost:5000/__admin__/**

默认登录凭证：
- 用户名：`admin`
- 密码：`admin123`

## 📋 配置

```python
# 在 Flask 配置中
class Config:
    SECRET_KEY = 'your-secret-key'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///app.db'
    ADMIN_TITLE = '我的管理后台'
    MONITOR_LOG_TTL_DAYS = 30
```

## 📊 支持的 ORM

| ORM | 状态 |
|-----|------|
| SQLAlchemy | ✅ 完全支持 |
| Peewee | ✅ 支持 |
| Tortoise ORM | 🔄 部分支持 |

## 📁 目录结构

```
flask-admin-pro/
├── src/flask_admin_pro/    # 包源码
│   ├── __init__.py
│   ├── core/               # 核心功能
│   ├── admin/              # 管理后台
│   └── models/             # 数据模型
├── tests/                  # 测试
├── pyproject.toml          # 项目配置
├── setup.py                # 安装脚本
└── README.md               # 说明文档
```

## 🧪 测试

```bash
# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest tests/

# 带覆盖率
pytest tests/ --cov=flask_admin_pro
```

## 🛡️ 安全建议

1. 生产环境修改 `SECRET_KEY`
2. 修改默认管理员密码
3. 启用 HTTPS
4. 配置 IP 白名单（可选）
5. 设置 `SESSION_COOKIE_SECURE = True`

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 🔗 链接

- [PyPI](https://pypi.org/project/flask-admin-pro/)
- [GitHub](https://github.com/yourusername/flask-admin-pro)
- [文档](https://github.com/yourusername/flask-admin-pro#readme)
- [问题反馈](https://github.com/yourusername/flask-admin-pro/issues)
